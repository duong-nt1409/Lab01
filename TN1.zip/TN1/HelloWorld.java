public class  HelloWorld{
    public static void main(String[] args) {
        System.out.println("xin chao \n cac ban!");
        System.out.println("Hello \t World!");
    }
}
